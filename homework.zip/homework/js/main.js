/* Add new text in square */
$('.text_value').change(function () {
    $text = $('.text_value').val();
    $string = $text.replace(/[<br>\\\/';  ]/g, '');
    $('.square_content').append($string + '<br>');
    $('.text_value').val('');
});

/* Change font size on the square*/
$('.font_size').keyup(function () {
    $int_value = $(this).val();
    $check_int = $.isNumeric($int_value);
    if ($check_int && $int_value <= 100) {
        $('.square_content').css({ 'font-size': $int_value + 'px', 'transition': '0.3s' });
    };
});

/* Change text color on the square */
function textColor() {
    $text_color = $('.text_color').val();
    $('.square_content').css({ 'color': $text_color, 'transition': '0.3s' });
}

/* Change width of the square */
$('.width_input').keyup(function () {
    $width = $(this).val();
    $check_int = $.isNumeric($width);
    if ($check_int && $width <= 500) {
        $('.square').css({ 'width': $width + 'px', 'transition': '0.3s' });
    }
});

/* Change height of the square */
$('.height_input').keyup(function () {
    $height = $(this).val();
    $check_int = $.isNumeric($height);
    if ($check_int && $height <= 500) {
        $('.square').css({ 'height': $height + 'px', 'transition': '0.3s' });
    }
});

/* Change background color of the square */
function backgroundColor() {
    $bg_color = $('.bg_color').val();
    $('.square').css({ 'background-color': $bg_color, 'transition': '0.3s' });
}

/* Change border radius of the square */
$('.border_radius').keyup(function () {
    $radius = $(this).val();
    $check_int = $.isNumeric($radius);
    if ($check_int && $radius <= 500) {
        $('.square').css({ 'border-radius': $radius + 'px', 'transition': '0.3s' });
    }
});

/* Change border width of the square */
$('.border_width').keyup(function () {
    $b_width = $(this).val();
    $check_int = $.isNumeric($b_width);
    if ($check_int && $b_width <= 50) {
        $('.square').css({ 'border-width': $b_width + 'px', 'transition': '0.3s' });
    }
});

/* Change border style of the square */
function changeBorder() {
    $border = $('.select_border').val();
    $('.square').css({ 'border-style': $border, 'transition': '0.3s' });
};

/* Change border color of the square */
function borderColor() {
    $border_color = $('.border_color').val();
    $('.square').css({ 'border-color': $border_color, 'transition': '0.3s' });
}